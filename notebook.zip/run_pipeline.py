import json

import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
import pickle

from src.config import (
    RAW_CSV,
    NROWS,
    RANDOM_STATE,
    TEST_SIZE,
    MODELS_DIR,
    REPORTS_DIR,
)
from src.evaluate import evaluate_model
from src.features import add_features
from src.preprocessing import prepare_inputs, build_preprocessor
from src.train import train_models
from src.split_data import separate_target,train_test
from src.cleaning import load_sample, clean_data, separate_inputs_target

def main():
    print("LOAD DATA")
    data = load_sample(RAW_CSV, NROWS, RANDOM_STATE)

    # EDA on loaded data

    print("CLEAN DATA") #binary tagrets, drop redudant cols(missing values, duplciates and not needed cols), cleaned date features
    data = clean_data(data)

    print("separate input and output")
    raw_inputs, y = separate_target(data)

    # Save original input fields for API validation.
    schema = {
        "columns": raw_inputs.columns.tolist(),
        "numeric": raw_inputs.select_dtypes(
            include="number"
        ).columns.tolist(),
    }

    print("FEATURE ENGINEERING")
    engineered = add_features(raw_inputs)
    

    print("SPLIT")
    X_train, X_test, y_train, y_test = split_data(X, y)

    print("IMPUTE AND TRANSFORM")
    preprocessor = build_preprocessor(X_train)
    X_train_processed = preprocessor.fit_transform(X_train)

    print("TRAIN")
    models = train_models(X_train_processed, y_train)

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    results = {}
    pipelines = {}

    for name, model in models.items():
        pipeline = Pipeline([
        ("preprocessing", preprocessor),
        ("model", model),
    ])

    print(f"EVALUATE: {name}")
    results[name] = evaluate_model(pipeline, X_test, y_test)
    pipelines[name] = pipeline

    print("SAVE MODELS")
    for name, pipeline in pipelines.items():
        with open(MODELS_DIR / f"{name}_pipeline.pkl", "wb") as file:
            pickle.dump(pipeline, file)

if __name__ == "__main__":
    main()