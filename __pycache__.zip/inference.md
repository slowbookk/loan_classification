

# Key Inferences (EDA & Modeling)

*Train set: ~7,100 loans | Global Default Rate: 19.2%*

### 1. Target & Metrics
* **Imbalance:** 81% Paid / 19% Charged Off (~4:1).
* **Metric:** Avoid Accuracy; optimize **PR-AUC & Recall** with `class_weight='balanced'`.

### 2. Top Predictors of Default
* **Pricing & Risk:** High `int_rate` (14.8% vs 11.4%), longer `term` (60m >> 36m), and lower `fico_range_low` are strongest.
* **Credit Grade:** Strong monotonic rise in default from **Grade A (4.6%) to Grade G (60.7%)**.
* **Credit Thirst:** Defaulters have more recent inquiries (`inq_last_6mths`) and newly opened accounts.
* **Demographics:** Renters default more (23%) than homeowners (16%). State (`addr_state`) shows negligible signal.

### 3. Preprocessing Fixes (Fit on Train)
* **Skewed Tails:** `log1p` on `annual_inc`, `revol_bal`, `tot_cur_bal`.
* **Outlier Cap:** Cap `dti` at 50 (removes data errors up to 999).
* **Impute:** Train median for numbers (`emp_length`), mode for categories.
* **Zero-Heavy:** Convert sparse features (`tax_liens`, `delinq_amnt`) to binary flags.

### 4. Drops Before Modeling
* **Leakage:** `debt_settlement_flag` (assigned *after* default $\rightarrow$ 100% target leak).
* **Near-Constant:** `application_type` (>99.4% "Individual" $\rightarrow$ zero signal).

### 5. Multicollinearity
* **Redundant Pairs ($r \ge 0.70$):** Keep only 1 per family (`open_acc` over `num_sats`, `tot_cur_bal` over `tot_hi_cred_lim`).
* **Keep Both:** `grade` + `term` (60m is riskier across every grade $\rightarrow$ independent signals).




