import pandas as pd


DOMAIN_DROP_COLS = [
    # Identifiers and text
    "id", "member_id", "url",
    "desc", "emp_title", "title", "zip_code",

    # Redundant or excluded fields
    "funded_amnt", "funded_amnt_inv",
    "sub_grade", "fico_range_high",
    "installment", "purpose", "initial_list_status",

    # Delinquency fields
    "num_tl_90g_dpd_24m", "num_accts_ever_120_pd",
    "mths_since_last_delinq", "delinq_2yrs",

    # Inquiry fields
    "inq_last_12m", "inq_fi", "mths_since_recent_inq",

    # Recent account-opening fields
    "open_acc_6m", "acc_open_past_24mths",
    "num_tl_op_past_12m",

    # Detailed bankcard fields
    "bc_open_to_buy", "bc_util", "max_bal_bc",
    "num_actv_bc_tl", "num_bc_sats", "num_bc_tl",
    "mths_since_recent_bc", "percent_bc_gt_75",
    "total_bc_limit",

    # Post-loan leakage
    "out_prncp", "out_prncp_inv",
    "total_pymnt", "total_pymnt_inv",
    "total_rec_prncp", "total_rec_int",
    "total_rec_late_fee", "recoveries",
    "collection_recovery_fee",
    "last_pymnt_d", "last_pymnt_amnt",
    "next_pymnt_d", "last_credit_pull_d",
    "last_fico_range_high", "last_fico_range_low",
    "debt_settlement_flag",

    # Other exclusions and original target
    "issue_d", "application_type", "loan_status",
]

DATE_COLS = ["earliest_cr_line"]


def load_sample(path, nrows, random_state=42):
    """Read the first nrows and shuffle reproducibly."""
    data = pd.read_csv(
        path,
        nrows=nrows,
        low_memory=False,
    )

    return data.sample(
        frac=1,
        random_state=random_state,
    ).copy()


def make_binary_target(data):
    data = data[
        data["loan_status"].isin(["Fully Paid", "Charged Off"])
    ].copy()

    data["target"] = data["loan_status"].map({
        "Fully Paid": 0,
        "Charged Off": 1,
    })

    return data


def drop_domain_and_leakage(data):
    return data.drop(
        columns=DOMAIN_DROP_COLS,
        errors="ignore",
    )


def clean_term_emp_length_dates(data):
    data = data.copy()

    replacements = {
        "< 1 year": "0",
        "10+ years": "10",
        "n/a": pd.NA,
    }

    for column in ["term", "emp_length"]:
        if column in data:
            values = data[column].astype("string")

            if column == "emp_length":
                values = values.replace(replacements)

            data[column] = pd.to_numeric(
                values.str.extract(r"(\d+)", expand=False),
                errors="coerce",
            )

    for column in DATE_COLS:
        if column in data:
            data[column] = pd.to_datetime(
                data[column],
                format="%b-%Y",
                errors="coerce",
            )

    return data


def clean_data(data):
    data = make_binary_target(data)
    data = drop_domain_and_leakage(data)
    return clean_term_emp_length_dates(data)


def separate_inputs_target(data):
    X = data.drop(columns="target").copy()
    y = data["target"].astype(int)

    return X, y