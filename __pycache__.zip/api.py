import json
from typing import Any

import joblib
import numpy as np
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from src.cleaning import clean_term_emp_length_dates
from src.config import MODELS_DIR
from src.features import add_features
from src.preprocessing import prepare_inputs


app = FastAPI()

models = {
    name: joblib.load(MODELS_DIR / f"{name}_pipeline.pkl")
    for name in ["logistic", "random_forest"]
}

schema = json.loads(
    (MODELS_DIR / "input_schema.json").read_text()
)


class LoanInput(BaseModel):
    features: dict[str, Any]


def prepare_request(features):
    extra = sorted(set(features) - set(schema["columns"]))
    if extra:
        raise ValueError(f"Unknown fields: {extra}")

    data = pd.DataFrame([features]).reindex(
        columns=schema["columns"]
    )
    data = clean_term_emp_length_dates(data)

    numeric = schema["numeric"]
    data[numeric] = data[numeric].apply(
        pd.to_numeric,
        errors="raise",
    )

    if np.isinf(data[numeric].to_numpy(dtype=float)).any():
        raise ValueError("Numeric inputs must be finite.")

    if not data.loc[0, "loan_amnt"] > 0:
        raise ValueError("loan_amnt is required and must be positive.")

    data = add_features(data)
    X, _, _ = prepare_inputs(data)

    return X


@app.post("/predict")
def predict(loan: LoanInput):
    try:
        X = prepare_request(loan.features)
        results = {}

        for name, model in models.items():
            probability = float(model.predict_proba(X)[0, 1])

            results[name] = {
                "prediction": int(probability >= 0.5),
                "default_probability": round(probability, 4),
            }

        return results

    except (ValueError, TypeError) as error:
        raise HTTPException(422, detail=str(error)) from error