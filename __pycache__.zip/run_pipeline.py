import json

import joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline


from src.config import (
    RAW_CSV,
    NROWS,
    RANDOM_STATE,
    TEST_SIZE,
    MODELS_DIR,
    REPORTS_DIR,
)
from src.evaluate import evaluate_model
from src.features import add_features
from src.preprocessing import prepare_inputs, build_preprocessor
from src.train import train_models

from src.cleaning import load_sample, clean_data, separate_inputs_target

def main():
    print("LOAD DATA")
    data = load_sample(RAW_CSV, NROWS, RANDOM_STATE)

    # EDA

    print("CLEAN DATA") #binary tagrets, drop redudant cols(missing values, duplciates and not needed cols), cleaned date features
    data = clean_data(data)

    print("separate input and output")
    raw_inputs, y = separate_inputs_target(data)

    # Save original input fields for API validation.
    schema = {
        "columns": raw_inputs.columns.tolist(),
        "numeric": raw_inputs.select_dtypes(
            include="number"
        ).columns.tolist(),
    }

    print("FEATURE ENGINEERING")
    engineered = add_features(raw_inputs)
    X, nums, cats = prepare_inputs(engineered)

    print("SPLIT")
    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        random_state=RANDOM_STATE,
        stratify=y,
    )

    print("IMPUTE AND TRANSFORM")
    preprocessor = build_preprocessor(nums, cats)
    X_train_processed = preprocessor.fit_transform(X_train)

    print("TRAIN")
    models = train_models(X_train_processed, y_train)

    MODELS_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)

    results = {}

    for name, model in models.items():
        pipeline = Pipeline([
            ("preprocessing", preprocessor),
            ("model", model),
        ])

        print(f"\nEVALUATE: {name}")
        results[name] = evaluate_model(
            pipeline,
            X_test,
            y_test,
        )

        joblib.dump(
            pipeline,
            MODELS_DIR / f"{name}_pipeline.pkl",
        )

    (MODELS_DIR / "input_schema.json").write_text(
        json.dumps(schema, indent=2)
    )

    (REPORTS_DIR / "model_metrics.json").write_text(
        json.dumps(results, indent=2)
    )

    print("\nSaved models, input schema, and metrics.")


if __name__ == "__main__":
    main()